
var{serverStaticFile,handelhomepage,handelError}=require("./handelr/function.js")
function router(req, res) {
  var endponit = req.url;
  if (endponit === "/") {
    handelhomepage(req, res);
  } else if (endponit.includes("public")) {
    serverStaticFile(req, res);
  } else {
    handelError(res);
  }
}

module.exports=router;
