var http = require("http");
var fs = require("fs");
var path = require("path");
var router =require("./router.js");


var server = http.createServer(router);

server.listen(4000, function() {
  console.log("server");
});
